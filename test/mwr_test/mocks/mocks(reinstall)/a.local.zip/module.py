This is an edited local, archived module.
